import "./global.css";
import "./style.css";
// import Chart from "chart.js/auto";
import * as d3 from "d3";
let width = 450;
let height = 450;
let margin = 40;

function loadChart(data: { key: string; value: number }[]) {
  d3.select("#chartContainer svg").remove();
  const chart = d3
    .select("#chartContainer")
    .append("svg")
    .attr("width", 500)
    .attr("height", 500)
    .append("g")
    .attr("transform", "translate(" + width / 2 + "," + height / 2 + ")");

  var radius = Math.min(width, height) / 2 - margin;

  const pie = d3.pie().value((d: any) => d.value);
  const data_ready = pie(data as any);

  const arc = d3.arc().innerRadius(0).outerRadius(radius);

  chart
    .selectAll("allSlices")
    .data(data_ready)
    .enter()
    .append("path")
    .attr("d", arc as any)
    .attr("fill", (d: any, i: any) => {
      return d3.schemeSet2[i];
    })
    .attr("stroke", "white")
    .style("stroke-width", "2px")
    .style("opacity", 0.7);

  chart
    .append("circle")
    .attr("cx", 0)
    .attr("cy", 0)
    .attr("r", radius * 0.6)
    .attr("fill", "var(--background-color)")
    .attr("stroke", "white")
    .style("stroke-width", "2px");

  //animate the pie chart

  const animatePie = () => {
    chart
      .selectAll("path")
      .transition()
      .duration(500)
      .attrTween("d", function (d: any): any {
        var i = d3.interpolate(d.startAngle + 0.1, d.endAngle);
        return function (t: any) {
          d.endAngle = i(t);
          return arc(d);
        };
      });
  };

  animatePie();

  document.querySelectorAll(".btnFilter").forEach((btn) => {
    btn.addEventListener("click", async (e) => {
      let target = e.target as HTMLButtonElement;
      let type = target.dataset.type;
      // let data = await loadData(type);
      let data = [
        { key: "A", value: Math.round(Math.random() * 10) },
        { key: "B", value: Math.round(Math.random() * 10) },
        { key: "C", value: Math.round(Math.random() * 10) },
        { key: "D", value: Math.round(Math.random() * 10) },
        { key: "E", value: Math.round(Math.random() * 10) }
      ];
      loadChart(data);
    });
  });
}

let data = [
  { key: "A", value: Math.round(Math.random() * 10) },
  { key: "B", value: Math.round(Math.random() * 10) },
  { key: "C", value: Math.round(Math.random() * 10) },
  { key: "D", value: Math.round(Math.random() * 10) },
  { key: "E", value: Math.round(Math.random() * 10) }
];

loadChart(data);

//! WIP
// async function loadData(type: string) {
//   let res = await fetch(`/AGRIBALYSE3.1_bio_simplifie.tsv`);
//   let data = await res.text();
//   let tsv = d3.tsvParse(data);
//   console.log(tsv);
//   let filteredData = tsv.filter((d) => {
//     return d["Nom du Produit en Français (traduction approximative GoogleTranslate)"]?.includes(
//       type[0].toUpperCase() + type.slice(1)
//     );
//   });
//   console.log(filteredData);
//   let returnData = filteredData.map((d) => {
//     return {
//       key: d["Nom du Produit en Français (traduction approximative GoogleTranslate)"],
//       value: d["Changement climatique"]
//     };
//   });
//   console.log(returnData);
//   return returnData;
// }
